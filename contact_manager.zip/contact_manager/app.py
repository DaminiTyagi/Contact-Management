from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import re

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///contacts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Model
class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(15), nullable=False)

# Email validation
def is_valid_email(email):
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

# READ
@app.route('/')
def index():
    contacts = Contact.query.all()
    return render_template('index.html', contacts=contacts)

# CREATE
@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        email = request.form['email']

        if not is_valid_email(email):
            return "Invalid email format"

        if Contact.query.filter_by(email=email).first():
            return "Email already exists"

        new_contact = Contact(
            first_name=request.form['first_name'],
            last_name=request.form['last_name'],
            address=request.form['address'],
            email=email,
            phone=request.form['phone']
        )

        db.session.add(new_contact)
        db.session.commit()
        return redirect(url_for('index'))

    return render_template('add.html')

# UPDATE
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    contact = Contact.query.get_or_404(id)

    if request.method == 'POST':
        new_email = request.form['email']

        if not is_valid_email(new_email):
            return "Invalid email format"

        existing = Contact.query.filter_by(email=new_email).first()
        if existing and existing.id != id:
            return "Email already exists"

        contact.first_name = request.form['first_name']
        contact.last_name = request.form['last_name']
        contact.address = request.form['address']
        contact.email = new_email
        contact.phone = request.form['phone']

        db.session.commit()
        return redirect(url_for('index'))

    return render_template('edit.html', contact=contact)

# DELETE
@app.route('/delete/<int:id>')
def delete(id):
    contact = Contact.query.get_or_404(id)
    db.session.delete(contact)
    db.session.commit()
    return redirect(url_for('index'))

# RUN
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)